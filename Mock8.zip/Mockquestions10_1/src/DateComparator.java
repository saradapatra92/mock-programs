import java.text.SimpleDateFormat;
import java.util.Comparator;
import java.util.Date;

public class DateComparator implements Comparator<Note>{

	@Override
	public int compare(Note o1, Note o2) {
		// TODO Auto-generated method stub
		SimpleDateFormat sdf=new SimpleDateFormat("dd-MM-yyyy");
		String s1=sdf.format(o1.getCreatedDate());
		String s2=sdf.format(o2.getCreatedDate());
		Date d1=o1.getCreatedDate();
		Date d2=o2.getCreatedDate();
		return d1.compareTo(d2);
	}

}
