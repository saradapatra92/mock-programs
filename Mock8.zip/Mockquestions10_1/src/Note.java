import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Note implements Comparable<Note>{

	private String name;
	private String content;
	private double size;
	private double priorityLevel;
	private Date createdDate;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public double getSize() {
		return size;
	}
	public void setSize(double size) {
		this.size = size;
	}
	public double getPriorityLevel() {
		return priorityLevel;
	}
	public void setPriorityLevel(double priorityLevel) {
		this.priorityLevel = priorityLevel;
	}
	public Date getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}
	public Note(String name, String content, double size, double priorityLevel, Date createdDate) {
		super();
		this.name = name;
		this.content = content;
		this.size = size;
		this.priorityLevel = priorityLevel;
		this.createdDate = createdDate;
	}
	
	public Note() {
		// TODO Auto-generated constructor stub
	}
	public static Note createNote(String detail) throws NumberFormatException, ParseException{
		String[] arr=detail.split(",");
		SimpleDateFormat sdf=new SimpleDateFormat("dd-MM-yyyy");
		Note note=new Note(arr[0],arr[1],Double.parseDouble(arr[2]),Double.parseDouble(arr[3]),sdf.parse(arr[4]));
		return note;
	}
	@Override
	public int compareTo(Note o) {
		// TODO Auto-generated method stub
		String s1=this.getName();
		String s2=o.getName();
		return s1.compareTo(s2);
	}
}
