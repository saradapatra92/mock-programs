import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Main {

	public static void main(String[] args) throws NumberFormatException, IOException, ParseException {
		// TODO Auto-generated method stub
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		List<Note> noteList=new ArrayList<>();
		SimpleDateFormat sdf=new SimpleDateFormat("dd-MM-yyyy");
		System.out.println("Enter the numbers of the notes:");
		int n=Integer.parseInt(br.readLine());
		for(int i=0;i<n;i++){
			String str=br.readLine();
			Note note=Note.createNote(str);
			noteList.add(note);
		}
		System.out.println("1.sort by name\n2.sort by date\n3.sort by prioritylevel");
		int ch=Integer.parseInt(br.readLine());
		if(ch==1){
			System.out.format("%-15s %-20s %-5s %-15s %s\n", "Name","Content","Size","Priority level","Created date");
			Collections.sort(noteList);
			for (Note note : noteList) {
				System.out.format("%-15s %-20s %-5s %-15s %s\n", note.getName(),note.getContent(),note.getSize(),note.getPriorityLevel(),sdf.format(note.getCreatedDate()));
				
			}
		}
		else if(ch==2){
			System.out.format("%-15s %-20s %-5s %-15s %s\n", "Name","Content","Size","Priority level","Created date");
			Collections.sort(noteList,new DateComparator());
			for (Note note : noteList) {
				System.out.format("%-15s %-20s %-5s %-15s %s\n", note.getName(),note.getContent(),note.getSize(),note.getPriorityLevel(),sdf.format(note.getCreatedDate()));
				
			}
		}
		else if(ch==3){
			System.out.format("%-15s %-20s %-5s %-15s %s\n", "Name","Content","Size","Priority level","Created date");
			Collections.sort(noteList,new PriorityLevel());
			for (Note note : noteList) {
				System.out.format("%-15s %-20s %-5s %-15s %s\n", note.getName(),note.getContent(),note.getSize(),note.getPriorityLevel(),sdf.format(note.getCreatedDate()));
				
			}
		}

	}

}
