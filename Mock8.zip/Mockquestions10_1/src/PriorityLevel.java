import java.util.Comparator;

public class PriorityLevel implements Comparator<Note>{

	@Override
	public int compare(Note o1, Note o2) {
		// TODO Auto-generated method stub
		Double d1=o1.getPriorityLevel();
		Double d2=o2.getPriorityLevel();
		return d1.compareTo(d2);
	}

}
