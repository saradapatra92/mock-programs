import java.text.SimpleDateFormat;
import java.util.List;

public class NoteBook {

	private String name;
	private List<Note> noteList;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public List<Note> getNoteList() {
		return noteList;
	}
	public void setNoteList(List<Note> noteList) {
		this.noteList = noteList;
	}
	public NoteBook(String name, List<Note> noteList) {
		super();
		this.name = name;
		this.noteList = noteList;
	}
	
	 public NoteBook() {
		// TODO Auto-generated constructor stub
	}
	 
	 public void addNoteToBook(Note note){
		 noteList.add(note);
	 }
	 
	 public Boolean removeNoteFromBook(String name){
		 for (Note note : noteList) {
			if(note.getName().equals(name)){
				noteList.remove(note);
				return true;
			}
		}
		 return false;
	 }
	 
	 public void displayNotes(){
		 if(noteList.isEmpty()){
			 System.out.println("No notes to show");
		 }
		 else{
			 System.out.println("Notes in:"+name);
			 System.out.format("%-15s%-25s%-10s%-15s%-10s\n", "name", "content", "size", "createdDate", "priorityLevel");
			 for (Note note : noteList) {
				 SimpleDateFormat sdf=new SimpleDateFormat("dd-MM-yyyy");
				 System.out.format("%-15s%-25s%-10s%-15s%-10s\n",note.getName(),note.getContent(),note.getSize(),sdf.format(note.getCreatedDate()), note.getPriorityLevel());
			}
		 }
	 }
}
