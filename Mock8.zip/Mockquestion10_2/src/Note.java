import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Note {

	private String name;
	private String content;
	private double size;
	private Date createdDate;
	private double priorityLevel;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public double getSize() {
		return size;
	}
	public void setSize(double size) {
		this.size = size;
	}
	public Date getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}
	public double getPriorityLevel() {
		return priorityLevel;
	}
	public void setPriorityLevel(double priorityLevel) {
		this.priorityLevel = priorityLevel;
	}
	public Note(String name, String content, double size, Date createdDate, double priorityLevel) {
		super();
		this.name = name;
		this.content = content;
		this.size = size;
		this.createdDate = createdDate;
		this.priorityLevel = priorityLevel;
	}
	
	public Note() {
		// TODO Auto-generated constructor stub
	}
	
	public static Note createNote(String detail) throws NumberFormatException, ParseException{
		SimpleDateFormat sdf=new SimpleDateFormat("dd-MM-yyyy");
		String[] arr=detail.split(",");
		Note note=new Note(arr[0],arr[1],Double.parseDouble(arr[2]),sdf.parse(arr[3]),Double.parseDouble(arr[4]));
		return note;
	}
	
}
