import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.text.ParseException;
import java.util.ArrayList;

public class Main {

	public static void main(String[] args) throws IOException, NumberFormatException, ParseException {
		// TODO Auto-generated method stub

		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Enter the name of the book:");
		String str=br.readLine();
		NoteBook nb=new NoteBook(str, new ArrayList<Note>());
		do{
		System.out.println("1.Add Note\n2.Delete Note\n3.Display notes\n4.Exit");
		System.out.println("enter your choice");
		int ch=Integer.parseInt(br.readLine());
		if(ch==1){
			System.out.println("Enter the details of note in CSV format:");
			String s1=br.readLine();
			Note note=Note.createNote(s1);
			nb.addNoteToBook(note);
			System.out.println("note successfully added");
			
		}
		else if(ch==2){
			System.out.println("Enter the name of the note to be deleted:");
			String name=br.readLine();
			if(nb.removeNoteFromBook(name)){
				System.out.println("Note successfully deleted");
			}
			else{
				System.out.println("Note not found in the Book");
			}
		}
		else if(ch==3){
			nb.displayNotes();
		}
		else if(ch==4){
			System.exit(0);
		}
		}while(true);
		
	}

}
