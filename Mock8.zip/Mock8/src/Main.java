import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

public class Main {

	public static void main(String[] args) throws NumberFormatException, IOException, ParseException {
		// TODO Auto-generated method stub

		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		List<Mail> list=new ArrayList<>();
		MailBO m1=new MailBO();
		System.out.println("enter the number of mails:");
		int n=Integer.parseInt(br.readLine());
		for(int i=0;i<n;i++){
			String str=br.readLine();
			String[] arr=str.split(",");
			SimpleDateFormat sdf=new SimpleDateFormat("dd-MM-yyyy");
			Mail m=new Mail(Long.parseLong(arr[0]),arr[1],arr[2],arr[3],arr[4],sdf.parse(arr[5]),Double.parseDouble(arr[6]));
			list.add(m);
		}
		System.out.println("enter a search type:\n"+"1.by to address\n"+"2.By received date\n"+"3.By size");
		int ch=Integer.parseInt(br.readLine());
		if(ch==1){
			System.out.println("enter the to address");
			String str=br.readLine();
			System.out.format("%-10s%-20s%-25s%-20s%-20s%-15s%s\n","Id","To","From","Subject","Content","ReceivedDate","Size");
			List<Mail>list1=m1.findMail(list, str);
			for (Mail mail : list1) {
				System.out.println(mail);
			}
		}
		else if(ch==2){
			System.out.println("enter the receiveddate");
			String str=br.readLine();
			SimpleDateFormat sdf=new SimpleDateFormat("dd-MM-yyyy");
			System.out.format("%-10s%-20s%-25s%-20s%-20s%-15s%s\n","Id","To","From","Subject","Content","ReceivedDate","Size");
			List<Mail>list1=m1.findMail(list, sdf.parse(str));
			for (Mail mail : list1) {
				System.out.println(mail);
			}
		}
		else if(ch==3){
			System.out.println("enter the size");
			Double str=Double.parseDouble(br.readLine());
			System.out.format("%-10s%-20s%-25s%-20s%-20s%-15s%s\n","Id","To","From","Subject","Content","ReceivedDate","Size");
			List<Mail>list1=m1.findMail(list, str);
			for (Mail mail : list1) {
				System.out.println(mail);
			}
		}
		else{
			System.out.println("Invalid choice");
		}
	}

}
