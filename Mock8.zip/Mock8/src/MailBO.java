import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class MailBO {

	public List<Mail>findMail(List<Mail>mailList,String to){
		List<Mail> list=new ArrayList<>();
		for (Mail mail : mailList) {
			if(mail.getTo().equals(to)){
				list.add(mail);
			}
		}
		return list;
	}
	public List<Mail>findMail(List<Mail>mailList,Date receivedDate){
		List<Mail> list=new ArrayList<>();
		for (Mail mail :mailList) {
			if(mail.getReceivedDate().equals(receivedDate)){
				list.add(mail);
			}
		}
		return list;
	}
	public List<Mail>findMail(List<Mail>mailList,Double size){
		List<Mail> list=new ArrayList<>();
		for (Mail mail : mailList) {
			if(mail.getSize().equals(size)){
				list.add(mail);
			}
		}
		return list;
	}
}
