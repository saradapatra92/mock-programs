import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class Main1 {

	public static void main(String[] args) throws NumberFormatException, IOException, ParseException {
		// TODO Auto-generated method stub

		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		List<Call> list=new ArrayList<>();
		System.out.println("enter number of contact list");
		int n=Integer.parseInt(br.readLine());
		for(int i=0;i<n;i++){
			String str=br.readLine();
			String[] arr=str.split(",");
			SimpleDateFormat sdf=new SimpleDateFormat("dd-MM-yyyy");
			SimpleDateFormat sdf1=new SimpleDateFormat("HH:mm:ss");
			//List<Contact> caList=new Contact().prefill();
			Contact ca=new Contact();
			ca.setName(arr[4]);
			Call c1=new Call(arr[0],arr[1],sdf.parse(arr[2]),sdf1.parse(arr[3]), ca);
			list.add(c1);
		}
		System.out.println("1.By Name\n"+"2.By Date");
		System.out.println("enter the choice");
		int ch=Integer.parseInt(br.readLine());
		if(ch==1){
			System.out.println("Enter name");
			String str=br.readLine();
			List<Call> list1=CallBO.findName(list, str);
			for (Call call : list1) {
				System.out.println(call);
			}
		}
		else if(ch==2){
			System.out.println("Enter date");
			String str=br.readLine();
			SimpleDateFormat sdf=new SimpleDateFormat("dd-MM-yyyy");
			Date date=sdf.parse(str); 
			List<Call> list1=CallBO.findDate(list, date);
			for (Call call : list1) {
				System.out.println(call);
			}
		}
		
	}

}
