import java.text.SimpleDateFormat;
import java.util.Date;

public class Mail {

	private Long id;
	private String to;
	private String from;
	private String subject;
	private String content;
	private Date receivedDate;
	private Double size;
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getTo() {
		return to;
	}
	public void setTo(String to) {
		this.to = to;
	}
	public String getFrom() {
		return from;
	}
	public void setFrom(String from) {
		this.from = from;
	}
	public String getSubject() {
		return subject;
	}
	public void setSubject(String subject) {
		this.subject = subject;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public Date getReceivedDate() {
		return receivedDate;
	}
	public void setReceivedDate(Date receivedDate) {
		this.receivedDate = receivedDate;
	}
	public Double getSize() {
		return size;
	}
	public void setSize(Double size) {
		this.size = size;
	}
	public Mail(Long id, String to, String from, String subject, String content, Date receivedDate, Double size) {
		super();
		this.id = id;
		this.to = to;
		this.from = from;
		this.subject = subject;
		this.content = content;
		this.receivedDate = receivedDate;
		this.size = size;
	}
	
	public Mail() {
		// TODO Auto-generated constructor stub
	}
	
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		SimpleDateFormat sdf=new SimpleDateFormat("dd-MM-yyyy");
		return String.format("%-10s%-20s%-25s%-20s%-20s%-15s%s\n",getId(),getTo(),getFrom(),getSubject(),getContent(),sdf.format(getReceivedDate()),getSize());
	}
}
