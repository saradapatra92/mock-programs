import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class Contact {

	private String name;
	private String mobileNo;
	private String email;
	private Date date;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	public Contact(String name, String mobileNo, String email, Date date) {
		super();
		this.name = name;
		this.mobileNo = mobileNo;
		this.email = email;
		this.date = date;
	}
	public Contact() {
		// TODO Auto-generated constructor stub
	}
	
	public List<Contact> prefill() throws ParseException{
		List<Contact> list=new ArrayList<>();
		SimpleDateFormat sdf=new SimpleDateFormat("dd-MM-yyyy");
		list.add(new Contact("john","1234356556","dsafd@gmail.com",sdf.parse("23-01-2018")));
		list.add(new Contact("tim","1234356556","dsafd@gmail.com",sdf.parse("23-01-2018")));
		list.add(new Contact("berry","1234356556","dsafd@gmail.com",sdf.parse("23-01-2018")));
		list.add(new Contact("tom","1234356556","dsafd@gmail.com",sdf.parse("23-01-2018")));
		list.add(new Contact("jerry","1234356556","dsafd@gmail.com",sdf.parse("23-01-2018")));
		return list;
	}
}
