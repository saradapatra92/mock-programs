import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class CallBO {

	public static List<Call> findName(List<Call>contactList,String name){
		List<Call> list=new ArrayList<>();
		for (Call call : contactList) {
			if(call.getContact().getName().equals(name)){
				//System.out.println(call);
				//System.out.print("Name:"+name);
				list.add(call);
			}
		}
		return list;
	}
	
	public static List<Call> findDate(List<Call> contactList,Date date){
		List<Call> list=new ArrayList<>();
		for (Call call : contactList) {
			if(call.getDate().equals(date)){
				list.add(call);
			}
		}
		return list;
	}
}
