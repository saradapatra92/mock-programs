import java.util.Date;

public class Call {

	private String callType;
	private String type;
	private Date date;
	private Date duration;
	private Contact contact;
	public String getCallType() {
		return callType;
	}
	public void setCallType(String callType) {
		this.callType = callType;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	public Date getDuration() {
		return duration;
	}
	public void setDuration(Date duration) {
		this.duration = duration;
	}
	public Contact getContact() {
		return contact;
	}
	public void setContact(Contact contact) {
		this.contact = contact;
	}
	public Call(String callType, String type, Date date, Date duration, Contact contact) {
		super();
		this.callType = callType;
		this.type = type;
		this.date = date;
		this.duration = duration;
		this.contact = contact;
	}
	
	public Call() {
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "Call [callType=" + callType + ", type=" + type + ", date=" + date + ", duration=" + duration
				+ ", name=" + contact.getName() + "]";
	}
	
	
}
