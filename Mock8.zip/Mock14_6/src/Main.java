import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

public class Main {

	public static void main(String[] args) throws NumberFormatException, IOException, ParseException {
		// TODO Auto-generated method stub

		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		SimpleDateFormat sdf=new SimpleDateFormat("dd/MM/yyyy");
		UPI u=new UPI(); 
		System.out.println("enter the number of transactions");
		int n=Integer.parseInt(br.readLine());
		List<UPI> upiList=UPI.prefill();
		String[] arr=new String[n];
		for(int i=0;i<n;i++){
			arr[i]=br.readLine();
		}
		
		for (UPI upi : upiList) {
			List<Transaction> tList=new ArrayList<>();
			for(int i=0;i<n;i++){
				String[] x=arr[i].split(",");
				if(x[1].equals(upi.getNumber())){
				Transaction t=new Transaction(x[0], upi,Double.parseDouble(x[2]),sdf.parse(x[3]));
				tList.add(t);
				}
			}
			upi.getUser().setTransactionList(tList);
			
		}
		UPI u1=u.favouriteUPI(upiList);
		System.out.println("Maximum amount is transferred to "+u1.getUser().getName());
	}

}
