import java.util.Date;

public class Transaction {

	private String type;
	private UPI upi;
	private Double amount;
	private Date date;
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public UPI getUpi() {
		return upi;
	}
	public void setUpi(UPI upi) {
		this.upi = upi;
	}
	public Double getAmount() {
		return amount;
	}
	public void setAmount(Double amount) {
		this.amount = amount;
	}
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	public Transaction(String type, UPI upi, Double amount, Date date) {
		super();
		this.type = type;
		this.upi = upi;
		this.amount = amount;
		this.date = date;
	}
	
	public Transaction() {
		// TODO Auto-generated constructor stub
	}
	
}
