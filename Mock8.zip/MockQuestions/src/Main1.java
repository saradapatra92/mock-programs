
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Main1 {

	public static void main(String[] args) throws NumberFormatException, IOException {
		// TODO Auto-generated method stub

		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		String choice="";
		do{
		System.out.println("1)Email validation"+"\n"+"2)service provider");
		System.out.println("enter your choice");
		int ch=Integer.parseInt(br.readLine());
		if(ch==1){
			System.out.println("Enter the email to be validated:");
			String str=br.readLine();
			boolean b=validateEmailId(str);
			if(b){
				System.out.println("valid");
			}
			else{
				System.out.println("not valid");
			}
		}
		else if(ch==2){
			System.out.println("enter mobile no");
			String mobile=br.readLine();
			System.out.println(identifyServiceProvider(mobile));
		}
		System.out.println("do you want to continue");
		choice=br.readLine();
		}while(choice.equalsIgnoreCase("yes"));
	}

	public static Boolean validateEmailId(String email) {
		String reg = "^[A-Za-z][A-Za-z0-9_.]{1,}[@][A-Za-z]{1,}.[A-Za-z]{2,6}$";

		 
		 Pattern pattern = Pattern.compile(reg, Pattern.CASE_INSENSITIVE);
		 Matcher matcher = pattern.matcher(email);

		if(matcher.find()) {
			return true;
		}
		return false;

	}
	public static String identifyServiceProvider(String mobile){
		String str=mobile.substring(0,4);
		String msg="";
		
		String reg = "^[0-9]{10,10}$";

		 
		 Pattern pattern = Pattern.compile(reg, Pattern.CASE_INSENSITIVE);
		 Matcher matcher = pattern.matcher(mobile);

		if(!matcher.find()) {
			return "not identified";
		}
			
		///System.out.println(mobile);
		
		
		
		if(str.equals("9870")){

			
			msg="Airtel";
		}
		else if(str.equals("8180")){
			msg="vodafone";
		}
		else if(str.equals("7012")){
			msg="jio";
		}
		else{
			msg="not identified";
		}
		return msg;
	}


}
