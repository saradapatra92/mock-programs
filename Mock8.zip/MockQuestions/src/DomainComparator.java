import java.util.Comparator;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class DomainComparator implements Comparator<Contact>{

	@Override
	public int compare(Contact o1, Contact o2) {
		String reg = "^([A-Za-z][A-Za-z0-9_.]{1,})(@)([A-Za-z]{1,}).([A-Za-z]{2,6})$";

		 String s1=o1.getEmail();
		 String s2=o2.getEmail();
		 Pattern pattern = Pattern.compile(reg, Pattern.CASE_INSENSITIVE);
		 Matcher matcher = pattern.matcher(s1);
		 String domain1=" ";
		 if(matcher.find()){
			 //System.out.println(matcher.group(3));
			  domain1=matcher.group(3).toString();
		 }
		 Pattern pattern1 = Pattern.compile(reg, Pattern.CASE_INSENSITIVE);
		 Matcher matcher1 = pattern1.matcher(s2);
		 String domain2="";
		 if(matcher1.find()){
			 //System.out.println(matcher1.group(3));
			  domain2=matcher1.group(3).toString();
		 }
		 return domain1.compareTo(domain2);
	}

}
