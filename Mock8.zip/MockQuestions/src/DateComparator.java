import java.text.SimpleDateFormat;
import java.util.Comparator;

public class DateComparator implements Comparator<Contact>{

	@Override
	public int compare(Contact o1, Contact o2) {
		SimpleDateFormat sdf=new SimpleDateFormat("dd-MM-yyyy");
		String s1=sdf.format(o1.getDateCreated());
		String s2=sdf.format(o2.getDateCreated());
		return s1.compareTo(s2);
	}

	
}
