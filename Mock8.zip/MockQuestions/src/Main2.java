import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

public class Main2 {

	public static void main(String[] args) throws NumberFormatException, IOException, ParseException {
		// TODO Auto-generated method stub
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		ContactBO bo=new ContactBO();
		System.out.println("enter no");
		int n=Integer.parseInt(br.readLine());
		List<Contact> contactlist=new ArrayList();
		for (int i = 0; i < n; i++) {
			//System.out.println("Enter contact "+(i+1)+" details");
			String str = br.readLine();
			String[] arr = str.split(",");
			SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");
			Date d = sdf.parse(arr[6]);
			Contact c = new Contact(arr[0], arr[1], arr[2], arr[3], arr[4], arr[5], d);
			contactlist.add(c);
			
		}
		String choice="";
		do{
		System.out.println("1)Name"+"\n"+"2)Date created"+"\n"+"email domain");
		System.out.println("enter your choice");
		int ch=Integer.parseInt(br.readLine());
		if(ch==1){
			System.out.println("Enter the names");
			String str=br.readLine();
			String[] arr=str.split(",");
			List<String> list=Arrays.asList(arr);
			List<Contact>result=bo.findContact(contactlist, list);
			for (Contact contact : result) {
				System.out.println(contact);
			}
		}
		else if(ch==2){
			System.out.println("enter date");
			String str=br.readLine();
			SimpleDateFormat sdf=new SimpleDateFormat("dd-MM-yyyy");
			Date d=sdf.parse(str);
			List<Contact>result=bo.findContact(contactlist, d);
			for (Contact contact : result) {
				System.out.println(contact);
			}
			
					}
		else if(ch==3){
			System.out.println("enter email");
			String str=br.readLine();
			List<Contact>result=bo.findContact(contactlist, str);
			for (Contact contact : result) {
				System.out.println(contact);
			}
		}
		else{
			System.out.println("invalid choice");
		}
		}while(false);

	}

}
