import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ContactBO {

	public List<Contact> findContact (List<Contact> contactList,List<String> name){
		List<Contact> result=new ArrayList();
		for (Contact string : contactList) {
			if(name.contains(string.getName())){
				result.add(string);
			}
		}
		return result;
	}
	public List<Contact> findContact (List<Contact> contactList,Date dateCreated){
		List<Contact> result=new ArrayList();
		for (Contact string : contactList) {
			if(dateCreated.equals(string.getDateCreated())){
				result.add(string);
			}
		}
		return result;
	}
	public List<Contact> findContact (List<Contact> contactList,String emailDomain){
		List<Contact> result=new ArrayList();
		for (Contact string : contactList) {
			String reg = "^([A-Za-z][A-Za-z0-9_.]{1,})(@)([A-Za-z]{1,}).([A-Za-z]{2,6})$";

			 
			 Pattern pattern = Pattern.compile(reg, Pattern.CASE_INSENSITIVE);
			 Matcher matcher = pattern.matcher(string.getEmail());
			 if(matcher.find()){
				 //System.out.println(matcher.group(3));
				 if(matcher.group(3).toString().equals(emailDomain)){
					 result.add(string);
				 }
			 }
		}
		return result;
	}
	
}
