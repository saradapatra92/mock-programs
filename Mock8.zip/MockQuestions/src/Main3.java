import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Main3 {

	public static void main(String[] args) throws NumberFormatException, IOException, ParseException {
		// TODO Auto-generated method stub

		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		System.out.println("enter no");
		int n = Integer.parseInt(br.readLine());
		List<Contact> contactlist = new ArrayList();
		for (int i = 0; i < n; i++) {
			// System.out.println("Enter contact "+(i+1)+" details");
			String str = br.readLine();
			String[] arr = str.split(",");
			SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");
			Date d = sdf.parse(arr[6]);
			Contact c = new Contact(arr[0], arr[1], arr[2], arr[3], arr[4], arr[5], d);
			contactlist.add(c);

		}
		System.out.println("Enter ur choice");
		System.out.println("1)sort by name" + "\n" + "2)sort by date" + "\n" + "3)sort by email");
		int ch = Integer.parseInt(br.readLine());
		switch (ch) {

		case 1:
			Collections.sort(contactlist);
			for (Contact contact : contactlist) {
				System.out.println(contact);
			}
			break;
		case 2:
			Collections.sort(contactlist,new DateComparator());
			for (Contact contact : contactlist) {
				System.out.println(contact);
			}
			break;
		case 3:
			
			Collections.sort(contactlist,new DomainComparator());
			Map<String,Integer>mp=new HashMap<String,Integer>();
			for (Contact contact : contactlist) {
				System.out.println(contact);
				String reg = "^([A-Za-z][A-Za-z0-9_.]{1,})(@)([A-Za-z]{1,}).([A-Za-z]{2,6})$";
			 Pattern pattern = Pattern.compile(reg, Pattern.CASE_INSENSITIVE);
			 Matcher matcher = pattern.matcher(contact.getEmail());
			 if(matcher.find()){
				 String domain=matcher.group(3);
				 if(mp.containsKey(domain)){
					 mp.put(domain, mp.get(domain)+1);
				 }else{
					 mp.put(domain, 1);
				 }
			 }
			}
			for(Entry<String,Integer>entry:mp.entrySet()){
				System.out.println(entry.getKey()+"==>"+entry.getValue());
			}
			break;

		}
	}

}
