import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

public class Main {

	public static void main(String[] args) throws NumberFormatException, IOException, ParseException {
		// TODO Auto-generated method stub
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		List<UPI> upiList=new ArrayList<>();
		UPI u=new UPI();
		SimpleDateFormat sdf=new SimpleDateFormat("dd/MM/yyyy");
		System.out.println("Enter the number of transactions:");
		int n=Integer.parseInt(br.readLine());
		upiList=UPI.prefill();
		String[] arr=new String[n];
		for(int i=0;i<n;i++){
			arr[i]=br.readLine();
		}
		for (UPI upi : upiList) {
			List<Transaction> tList=new ArrayList<>();
			//for (Transaction transaction :upi.getUser().getTransactionList()) {
				for(int i=0;i<n;i++){
					String[] x=arr[i].split(",");
					
					if(x[1].equals(upi.getNumber())){
					Transaction tr=new Transaction(x[0], upi,Double.parseDouble(x[2]),sdf.parse(x[3]));
					tList.add(tr);
					}
				}
				upi.getUser().setTransactionList(tList);
			}
		List<Transaction> tList1=u.filterAndSort(upiList);
		System.out.printf("%-10s%-8s%-10s%s\n","UserName","Type","Amount","Date");
		for (Transaction transaction : tList1) {
			System.out.printf("%-10s%-8s%-10s%s\n",transaction.getUpi().getUser().getName(),transaction.getType(),transaction.getAmount(),sdf.format(transaction.getDate()));
		}
		}
	

	}


