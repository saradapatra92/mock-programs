import java.util.Date;
import java.util.List;

public class User {

	private String name;
	private String mobileNumber;
	private String email;
	private Date DOB;
	private UPI upi;
	private List<Transaction> transactionList;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getMobileNumber() {
		return mobileNumber;
	}
	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public Date getDOB() {
		return DOB;
	}
	public void setDOB(Date dOB) {
		DOB = dOB;
	}
	public UPI getUpi() {
		return upi;
	}
	public void setUpi(UPI upi) {
		this.upi = upi;
	}
	public List<Transaction> getTransactionList() {
		return transactionList;
	}
	public void setTransactionList(List<Transaction> transactionList) {
		this.transactionList = transactionList;
	}
	public User(String name, String mobileNumber, String email, Date dOB, UPI upi, List<Transaction> transactionList) {
		super();
		this.name = name;
		this.mobileNumber = mobileNumber;
		this.email = email;
		DOB = dOB;
		this.upi = upi;
		this.transactionList = transactionList;
	}
	
	public User() {
		// TODO Auto-generated constructor stub
	}
	
}
