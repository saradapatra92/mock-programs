import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class UPI {

	private String number;
	private String accountNumber;
	private User user;
	public String getNumber() {
		return number;
	}
	public void setNumber(String number) {
		this.number = number;
	}
	public String getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}
	public User getUser() {
		return user;
	}
	public void setUser(User user) {
		this.user = user;
	}
	public UPI(String number, String accountNumber, User user) {
		super();
		this.number = number;
		this.accountNumber = accountNumber;
		this.user = user;
	}
	
	public UPI() {
		// TODO Auto-generated constructor stub
	}
	
	
		public static List<UPI> prefill() throws ParseException {
			SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
			List<UPI> upiList=new ArrayList<>();
			User u;
			UPI upi;
			
			u = new User("Chandler","9876543210","chandler@gmail.com",sdf.parse("31/01/1990"),null,new ArrayList<Transaction>());
			upi = new UPI("chandler@okiob","723265243253",u);
			u.setUpi(upi);
			upiList.add(upi);
			
			u = new User("Mona","9898798652","mona@gmail.com",sdf.parse("27/02/1987"),null,new ArrayList<Transaction>());
			upi = new UPI("mona@ib","362261115213",u);
			u.setUpi(upi);
			upiList.add(upi);
			
			u = new User("Monica","9787621230","monica@gmail.com",sdf.parse("15/09/1988"),null,new ArrayList<Transaction>());
			upi = new UPI("monica@okiob","208265245359",u);
			u.setUpi(upi);
			upiList.add(upi);
			
			u = new User("Joe","9879865898","joe@gmail.com",sdf.parse("23/07/1992"),null,new ArrayList<Transaction>());
			upi = new UPI("joe@okicici","298265245213",u);
			u.setUpi(upi);
			upiList.add(upi);
			
			u = new User("Charlie","9856985620","charlie@gmail.com",sdf.parse("24/05/1982"),null,new ArrayList<Transaction>());
			upi = new UPI("charlie@boi","852652433334",u);
			u.setUpi(upi);
			upiList.add(upi);
			
			u = new User("Frank","9765659820","frank@gmail.com",sdf.parse("13/03/1993"),null,new ArrayList<Transaction>());
			upi = new UPI("frank@okhdfc","569265555213",u);
			u.setUpi(upi);
			upiList.add(upi);
			
			u = new User("Leslie","9595878580","leslie@gmail.com",sdf.parse("26/09/1989"),null,new ArrayList<Transaction>());
			upi = new UPI("leslie@oksbi","987265254113",u);
			u.setUpi(upi);
			upiList.add(upi);
			
			u = new User("Emma","9659659790","emma@gmail.com",sdf.parse("15/03/1993"),null,new ArrayList<Transaction>());
			upi = new UPI("emma@oksbi","723265245402",u);
			u.setUpi(upi);
			upiList.add(upi);
			
			u = new User("Jack","9873213210","jack@gmail.com",sdf.parse("24/01/1983"),null,new ArrayList<Transaction>());
			upi = new UPI("jack@okboi","102265245169",u);
			u.setUpi(upi);
			upiList.add(upi);
			
			return upiList;
		}
		public List<Transaction> filterAndSort(List<UPI> upiList){
			List<Transaction> tList=new ArrayList<>();
			for (UPI upi : upiList) {
				for (Transaction transaction : upi.getUser().getTransactionList()) {
					if(transaction.getType().equalsIgnoreCase("debit")){
						tList.add(transaction);
					}
				}
			}
			Collections.sort(tList);
			return tList;
		}
	}

